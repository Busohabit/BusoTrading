import java.rmi.NoSuchObjectException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.lang.IndexOutOfBoundsException;
import java.util.Scanner;

/**  Author - Musa Khan
Date - 19/04/2022
Purpose - This class is used represents the user and defines their interactions with the trading app.
It also stores information about the user in it's attributes.
*/
public class Account {
    private String name; //holds the users name as a string
    private double balance; //this stores the amount of money in the user's account as a double
    private ArrayList<Asset> portfolio; //this holds a list of the different assets owned by the user

    /** the constructor for the Account class
    it initializes all of its fields with balance being set to 0, name being equal to n, 
    and the portfolio being set to a new ArrayList holding objects of the type Asset
    */
    public Account(String n) {
        name = n; //sets name to n
        balance = 0; //sets balance to 0
        portfolio = new ArrayList<Asset>(); //creates a new ArrayList of the type Asset and stores it in the field portfolio
    } //END Account

    //sets the value held in the field name to the value represented by the parameter n
    public void setName(String n) {
        this.name = n; //sets name to n
    } //END setName

    //returns the value held in the name field of an Account object
    public String getName() {
        return this.name;
    } //END getName

    //sets the value held in the field balance to the value represented by the parameter amount
    public void setBalance(double amount) {
        this.balance = amount; //sets balance to amount
    } //END setBalance

    //returns the value held in the field balance of an Account object
    public double getBalance() {
        return this.balance;
    } //END getBalance

    //allows the user to withdraw money from their account
    public void withdrawAmount() {
        try {
            /**declares and initalizes the double variable amount to the result of calling the function TradingSystem.userInput() asking the user to
            give an amount that they want to withdraw from their account and converting it to a double using the function Double.parseDouble()
            */
            double amount = Double.parseDouble(TradingSystem.userInput("How much would you like to withdraw from your account?")); 
            //the if - else statement is used to make sure that the user can't withdraw more than they have in their account or withdraw an amount below zero 
            if (this.getBalance() < amount || amount < 0) {
                System.out.println("Error. Invalid request.");
            }
            else {
                setBalance(this.getBalance() - amount); //subtracts the amount given by the user from their accounts balance
            }
        } catch(NumberFormatException e) {
            System.out.println("Error. Input given is not valid."); //informs the user that the input they gave was invalid
            TradingSystem.viewOptions(this); //calls the static procedure viewOptions() from the TradingSystem class
        }
    } //END withdrawAmount
    
    //allows the user to deposit money into their account
    public void depositAmount() {
        try {
            /**declares and initalizes the double variable amount to the result of calling the function TradingSystem.userInput() asking the user to
            give an amount that they want to deposit into their account and converting it to a double using the function Double.parseDouble()
            */
            double amount = Double.parseDouble(TradingSystem.userInput("How much would you like to deposit into your account?"));
            //the if-else statement is used to prevent the user from deposit an amount below zero
            if (amount < 0) {
                System.out.println("Error. Invalid request.");
            }
            else {
                setBalance(this.getBalance() + amount); //adds the value stored in the variable amount to the value held in the field balance
            }
        } catch(NumberFormatException e) {
            System.out.println("Error. Input given is not valid."); //tells the user that they gave an invalid input
            TradingSystem.viewOptions(this); //calls the procedure TradingSystem.viewOptions()
        }
    } //END depositAmount

    //allows the user to add the Asset held in a to their portfolio 
    public void addToPortfolio(Asset a) {
        int index; //declares the integer variable index
        //the if-else statement to see the item is already in their portfolio using the method isAssetInPortfolio
        if (isAssetInPortfolio(a)) {
            index = assetInPortfolio(a); //finds the location of a in the portfolio and stores the result in index
            this.portfolio.get(index).setQuantity(this.portfolio.get(index).getQuantity() + 1); //increments the quantity of a by 1
        }
        else {
            this.portfolio.add(a);//adds a to their portfolio
        }
    } //END addToPortfolio

    //this is used to remove a from their portfolio
    public void removeFromPortfolio(Asset a) {
        int index; //declares the variable index
        //the if-else statement uses the function isAssetInPortfolio to check if the item is already in the user's portfolio
        if (isAssetInPortfolio(a)) {
            index = assetInPortfolio(a); //finds the location of a in the portfolio and stores the result in index
            //checks if the quantity of a in the user's portfolio is greater than 1 
            if (this.portfolio.get(index).getQuantity() > 1) {
                this.portfolio.get(index).setQuantity(this.portfolio.get(index).getQuantity() - 1); //decrements the quantity of a in the portfolio by 1
            }
            else {
                this.portfolio.remove(index); //removes a from the portfolio
            }
            a.sell(this); //calls the function sell on a
        } else {
            System.out.println("Error. The asset given is not in your portfolio."); //informs the user that a is not in their portfolio
        }
    } //END removeFromPortfolio

    //returns the asset held in the location represented by the integer index
    public Asset getAssetFromPortfolio(int index) {
        return this.portfolio.get(index);
    } //END getAssetFromPortfolio

    //checks if a is in the user's portfolio
    public Boolean isAssetInPortfolio(Asset a) {
        //loops through the user's portfolio 
        for (int i = 0; i < portfolio.size(); i++) {
            if(this.portfolio.get(i).getName().equals(a.getName())) {
                return true; //returns true if a is in the user's portfolio
            }
        }
        return false; //returns false if a is not in the user's portfolio
    } //END isAssetInPortfolio

    //returns the location of a within the portfolio
    public int assetInPortfolio(Asset a) {
        //loops through the arraylist portfolio until it finds the Asset a
        for(int i = 0; i < portfolio.size(); i++) {
            if(this.portfolio.get(i).getName().equals(a.getName())) {
                return i; //returns the location of a represented by the integer i
            } 
        } throw new NoSuchElementException();
    } //END assetInPortfolio

    //prints out each Asset stored in the user's portfolio
    public void viewPortfolio() {
        //the if-else statement is used to make sure that the portfolio is only printed if there are Assets within it
        if (this.portfolio.size() == 0) {
            System.out.println("\n  Your portfolio is empty."); 
        }
        else {
            Asset.viewAssets(this.portfolio); //calls the viewAssets function on the user's portfolio
        } 
    } //END viewPortfolio

    //allows the user to buy the Asset a
    public void buyAssets(Asset a) {
        //if-else statement to make sure that the Account object has a high enough balance to be able to afford to buy the Asset 
        if (Double.compare(this.getBalance(), a.getValue()) >= 0) {
            a.buy(this); //calls the buy function a
        }
        else {
            System.out.println("Error. You don't have enough money to make this investment."); //in case the user doesn't have enough money to buy a
        }
    } //END buyAssets
    
}//END Account