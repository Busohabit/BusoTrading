import java.rmi.NoSuchObjectException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**  Author - Musa Khan
Date - 19/04/2022
Purpose - This class represents the financial products being bought sold within the investment trading app.
*/

public class Asset {
    private String name; //this holds the name of the Asset object
    private double value; //holds the price of the Asset object
    private String symbol; //holds the symbol used as a shorthand for the Asset
    private int quantity; //holds the amount of an Asset object that is being represented in the trading app

    //constructor for the class Asset
    //takes in the three values and initalizes each attribute of the class
    public Asset(String n, double v, String s) {
        name = n; //sets name to n
        value = v; //sets value to v
        symbol = s; //sets symbol to s
        quantity = 1; //initalizes quantity to 1
    } //END Asset

    //sets the value held in the field name to the value held in n
    public void setName(String n) {
        this.name = n; //sets name to n
    } //END setName

    //returns the value held in the field name 
    public String getName() {
        return this.name; 
    } //END getName
    
    //sets field value to v 
    public void setValue(double v) {
        this.value = v; //sets value to v
    } //END setValue

    //returns the value held in the field value 
    public double getValue() {
        return this.value;
    } //END getValue

    //sets the value held in the field symbol to the value held in s
    public void setSymbol(String s) {
        this.symbol = s; //sets symbol to s
    } //END setSymbol

    //returns the value held in the field symbol
    public String getSymbol() {
        return this.symbol;
    }  //END getSymbol

    //sets the value held in the field quantity to the value held in q
    public void setQuantity(int q) {
        this.quantity = q; //sets quantity to q
    } //END setQuantity
    
    //returns the value held in the field quantity
    public int getQuantity() {
        return this.quantity;
    } //END getQuantity
 
    //this defines the String value returned when returning or outputting the values of Asset objects  
    public String toString() {
        return this.getName() + " (" + this.getSymbol() + ") - | $ " + this.getValue(); //the String format of an  Asset object
    } //END toString

    //this method is for when an Asset object is bought by the Account object a
    public void buy(Account a) {
        a.addToPortfolio(this); //calls the method addToPortfolio on a using an Asset object
        a.setBalance(a.getBalance() - this.getValue()); //removes the value of the Asset object from the balance of the account object
    } //END buy

    //this method adds the value of an Asset object from the Account a
    public void sell(Account a) {
        a.setBalance(a.getBalance() + this.getValue()); //adds the value of the Asset to the Account object a
    } //END sell

    //searchs through a list of Assets and matchs the symbol to an Asset and returns that Asset
    public static Asset assetInList(String symbol, ArrayList<Asset> assets) {
        Iterator<Asset> it = assets.iterator(); //creates an Iterator object from assets
        while(it.hasNext()){
            Asset asset = it.next(); //sets asset to the next Asset in the iteration
            //checks if symbol matches with the symbol of asset
            if (asset.getSymbol().equals(symbol.toUpperCase())){ 
                return asset; //returns the asset that has the same symbol
            }
        } throw new NoSuchElementException("Error. The symbol given doesn't exist as any kind of asset."); 
        //in case that symbol doesn't match with any element within the ArrayList
    } //END assetInList

    //prints out each item in an ArrayList of assets
    public static void viewAssets(ArrayList<Asset> assets) {
        Iterator<Asset> it = assets.iterator(); //creates an Iterator from assets
        int counter = 0; //declares and initializes the integer variable counter to 0
        while(it.hasNext()){
            Asset asset = it.next(); //sets asset to the next Asset in the iteration
            counter++; //increments counter
            System.out.println(counter + ". " + asset + " x" + asset.getQuantity()); //prints the counter, the asset, and result of asset.getQuantity
        }
    } //END viewAssets

    //creates the list of Assets that are going to be used in the Trading System and returns it
    public static ArrayList<Asset> createList() {
        ArrayList<Asset> assets = new ArrayList<Asset>(); //creates an ArrayList of Asset objects
        //this creates the Assets for the trading system and adds each item to assets
        assets.add(new Asset("Amazon", 3012.98, "AMZN")); 
        assets.add(new Asset("Tesla", 987.80, "TSLA"));
        assets.add(new Asset("Nike", 125.18, "NKE"));
        assets.add(new Asset("Apple", 167.88, "AAPL"));
        assets.add(new Asset("Pepsi", 173.46, "PEP"));

        return assets; //returns the ArrayList assets
    } //END createList
    
}//END Asset