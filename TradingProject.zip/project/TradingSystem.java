import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.lang.NumberFormatException;

/**  Author - Musa Khan
Date - 19/04/2022
Purpose - This class is used to run the investment trading app. 
It holds the main procedures and functions that allow the user to act within with the trading app.
*/

public class TradingSystem {
    
    //The method used to set up the investment trading app
    //it takes in an input and uses it to create the account object representing the user and then allows them to decide what they want to do next
    public static void tradeShares() {
        String name; //declares the String variable name
        System.out.println("BUSO TRADING"); 
        name = userInput("What is your name?");//takes in input by calling the function and stores it in the variable name
        Account user = new Account(name); //creates a new Account object called user using the value held in the name variable as an argument
        viewOptions(user); //calls the procedure viewOptions with the Account object user as an argument
    }//END tradeShares

    //takes in an input from the user after printing the value represented message and returns it
    public static String userInput(String message) {
        String givenInput; //declares the String variable givenInput
        Scanner scan= new Scanner(System.in); //this creates a new Scanner object called scan
        
        System.out.println(message); //prints the String value represented by message
        givenInput = scan.nextLine(); //stores the user's input in the variable givenInput
        
        return givenInput; //returns the value held in givenInput
    }//END userInput     

    //displays a list of Assets to the user and allows the user to purchase one
    public static void buyShares(Account ac) {    
        try {
            ArrayList<Asset> assets = Asset.createList(); //creates a list of Asset objects that the user can choose from 
            Asset.viewAssets(assets); //displays the objects held in the ArrayList assets
            /** uses Asset.assetInList and userInput to get a symbol for an asset in assets to return that Asset 
            so that that the Account class method buyAssets can be called on the result */
            ac.buyAssets(Asset.assetInList(userInput("Give the symbol of the Asset you want to buy?"), assets)); 
            viewOptions(ac); //goes back to the options list afterwards using the procedure viewOptions
        } catch(NoSuchElementException e) {
            System.out.println("Error. The asset given is not in your portfolio."); //in case the user gives an invalid response
            viewOptions(ac); //goes back to the options list using the procedure viewOptions
        }
    } //END buyShares

    //displays the user's portfolio to them and allows them to choose which asset they want to sell
    public static void sellShares(Account ac) {
        try {
            int index; //declares the integer variable index
            Asset product; //declares the Asset variable product
            ac.viewPortfolio(); //allows them to view their portfolio by calling the viewPortfolio
            //takes in an input and converts it into an integer and then stores the result in index
            index = Integer.parseInt(userInput("Give the number of the Asset in your portfolio you want to sell?"));
            product = ac.getAssetFromPortfolio(index-1); //sets product to the result of ac.getAssetFromPortfolio with the argument of index - 1
            ac.removeFromPortfolio(product); //sells the product by call the removeFromPortfolio procedure on it through ac
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Error. The number you gave was invalid."); //exception for invalid numbers 
        } catch(NumberFormatException e) {
            System.out.println("Error. The input you gave was invalid."); //exception for invalid responses
        } catch(InputMismatchException e) {
            System.out.println("Error. The input you gave was invalid."); //exception for invalid inputs
        }
        finally {
            viewOptions(ac); //goes back to the options list to keep the program going by calling the procedure viewOptions
        }
    } //END sellShares

    //gives the user a list of choices for what they can do in the trading app, takes in their input and responds appropriately
    public static void viewOptions(Account ac) {
        int usersChoice; //declares the integer variable usersChoice
        //prints a list of options for the user to choose from
        System.out.println("\n    What would you like to do " + ac.getName() + "?\n");
        System.out.println("1. Would you like to buy any shares?");
        System.out.println("2. Would you like to sell your shares?");
        System.out.println("3. Would you like to view your portfolio?");
        System.out.println("4. Would you like to view your balance?");
        System.out.println("5. Would you like to deposit funds into your account?");
        System.out.println("6. Would you like to withdraw funds from your account");
        System.out.println("7. Exit");
        try {
            //takes in the user's response and converts it to an integer and stores the result in the variable usersChoice
            usersChoice = Integer.parseInt(userInput("")); 
            checkOptions(usersChoice, ac); //calls checkOptions to give a response to the user's input
            viewOptions(ac); //keeps the trading app going by calling viewOptions recursively so that the user can continue using the app
        } catch (NumberFormatException e) {
            System.out.println("Error. Input given is not a valid response.");
            viewOptions(ac); //allows the user to choose again after an invalid response by calling viewOptions
        }
    } //END viewOptions

    //uses the integer chosenOption to determine what method should be called on the Account object ac
    public static void checkOptions(int chosenOption, Account ac) {
        //switch-case for the different possible options available to the user
        switch (chosenOption) {
            case 1: 
                buyShares(ac); //calls the buyShares procedure on ac
                break;
            case 2:
                sellShares(ac); //calls the sellShares procedure on ac
                break;
            case 3:
                ac.viewPortfolio(); //calls the procedure viewPortfolio using ac
                break;
            case 4:
                System.out.println("Your current balance is: " + ac.getBalance()); //prints the ac's current balance using the getBalance function
                break;
            case 5:
                ac.depositAmount(); //calls the method depositAmount using ac
                break;
            case 6:
                ac.withdrawAmount(); //calls the method depositAmount using ac
                break;
            case 7: 
                System.exit(0); //exits the program entirely
                 break;
            default: //in case the user gives an invalid input
                System.out.println("Error. Number given is invalid");
                viewOptions(ac); //allows them to choose again by calling viewOptions with ac as an argument
                break;
        }
    } //END checkOptions

    //the main method which is called when the program is compiled and run to use the trading app
    public static void main(String[] args) {
        TradingSystem.tradeShares(); //calls the static method tradeShares to start the trading system up
    } //END main

}//END TradingSystem